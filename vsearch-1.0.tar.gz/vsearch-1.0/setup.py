from setuptools import setup

setup(name='vsearch',
      version='1.0',
      description='The vowels search tool',
      author='Mukul',
      author_email='mkul92@gmail.com',
      url='https://www.linkedin.com/in/mukulkumar9th/',
      py_modules=['vsearch'],
      )